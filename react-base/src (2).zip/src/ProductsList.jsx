import Product from "./Product"

function ProductsList() {
    return (
        <div>
            <h1>products List</h1>
            <Product/>
            <Product/>
            <div className="product">
                <h2>mouse</h2>
                <p>Rs:1000</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam, blanditiis at! Eos maieat totam.</p>
            </div>
        </div>
    )
}

export default ProductsList
