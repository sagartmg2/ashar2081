export default function Product() {
    return (
        <div className="product">
            <h2>watch</h2>
            <p>Rs:1000</p>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam, blanditiis at! Eos maieat totam.</p>
        </div>
    )
}
