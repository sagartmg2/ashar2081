export default function Banner() {
    return (
        <div>
            <img
                className="banner-image"
                src="https://fastly.picsum.photos/id/1045/1920/1080.jpg?hmac=GRfiiVtl8CWbA03mQfD3w-GjeND0f1XdchlCzqbIehA"
                alt=""
            />
            <p>banner description</p>
        </div>
    )
}
