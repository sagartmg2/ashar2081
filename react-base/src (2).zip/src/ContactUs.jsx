
export default function ContactUs() {
  return (
    <div>
            <h1>Contact us</h1>
            <ul>
                <li>member 1</li>
                <li>member 2</li>
                <li>member 3</li>
            </ul>
        </div>
  )
}
