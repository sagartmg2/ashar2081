import Product from "./Product"
import Card from "./Card"

function ProductsList() {
    let title = "Proudcts List"
    let products = [
        {
            featured: true,
            title: "watch",
            oldPrice: 1200,
            price: 1000,
            description: "em ipsum, dolor sit amet consectetur adipisicing elit. Excepturi ea odio, perferendis,",
        },
        {
            featured: false,
            title: "mouse",
            oldPrice: 11200,
            price: 11000,
            description: "em ipsum, dolor sit amet consectetur adipisicing elit. Excepturi ea odio, perferendis,",
        },
        {
            featured: false,
            title: "kewyord",
            oldPrice: 1300,
            price: 100,
            description: "em ipsum, dolor sit amet consectetur adipisicing elit. Excepturi ea odio, perferendis,",
        },
    ]
    return (
        <div>
            <div id="products-list" className="product-list">
                <h1>Featrued products</h1>
                <hr />
                <Product
                    title={products[0].title}
                    oldPrice={products[0].oldPrice}
                    price={products[0].price}
                    description="loream ipsum..."
                />
                <Product
                    title={products[1].title}
                    oldPrice={products[1].oldPrice}
                    price={products[1].price}
                    description="loream ipsum..."
                />
                <Product
                    title={products[2].title}
                    oldPrice={products[2].oldPrice}
                    price={products[2].price}
                    description="loream ipsum..."
                />

                {/* 

                    {
                        [ <Card product={products[0]} />, <Card product={products[1]} />, <Card product={products[1]} />]
                    }
            */}

                {products.map((el) => {
                    return <Card product={el} />
                })}

                <h1>Normal Producs</h1>

                {/* <Product title="skeybord" oldPrice="700" price="500" description="loream ipsum..." />
            <Product title="smouse" oldPrice="1700" price="1500" description="loream ipsum..." />
            <Product title="swatch 10" oldPrice="1700" price="1500" description="loream ipsum..." />
            <Product title="smobile" oldPrice="1700" price="15000" description="loream ipsum..." /> */}
            </div>
        </div>
    )
}

export default ProductsList
